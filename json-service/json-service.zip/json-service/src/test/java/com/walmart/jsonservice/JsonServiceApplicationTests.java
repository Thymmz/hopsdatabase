package com.walmart.jsonservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
