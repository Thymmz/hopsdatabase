package com.walmart.jsonservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonServiceApplication.class, args);
	}

}
