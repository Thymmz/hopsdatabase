package com.walmart.hopsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopsServiceApplication.class, args);
	}

}
