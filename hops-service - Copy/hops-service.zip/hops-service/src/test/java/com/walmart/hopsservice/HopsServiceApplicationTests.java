package com.walmart.hopsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HopsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
