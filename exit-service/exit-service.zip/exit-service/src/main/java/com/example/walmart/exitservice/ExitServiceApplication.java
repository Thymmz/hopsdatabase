package com.example.walmart.exitservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExitServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExitServiceApplication.class, args);
	}

}
