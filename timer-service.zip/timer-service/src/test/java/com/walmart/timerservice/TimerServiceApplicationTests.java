package com.walmart.timerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
