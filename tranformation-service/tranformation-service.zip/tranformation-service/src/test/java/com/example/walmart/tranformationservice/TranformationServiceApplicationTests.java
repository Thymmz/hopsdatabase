package com.example.walmart.tranformationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranformationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
