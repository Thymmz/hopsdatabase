package com.example.walmart.tranformationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranformationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TranformationServiceApplication.class, args);
	}

}
