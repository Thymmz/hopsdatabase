package com.example.walmart.orcusservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrcusServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrcusServiceApplication.class, args);
	}

}
