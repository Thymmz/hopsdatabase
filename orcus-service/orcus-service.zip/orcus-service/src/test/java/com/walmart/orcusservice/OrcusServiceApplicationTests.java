package com.walmart.orcusservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrcusServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
